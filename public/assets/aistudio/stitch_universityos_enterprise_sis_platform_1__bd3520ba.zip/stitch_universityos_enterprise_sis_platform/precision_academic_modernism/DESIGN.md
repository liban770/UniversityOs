---
name: Precision Academic Modernism
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#444748'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#b7131a'
  on-secondary: '#ffffff'
  secondary-container: '#db322f'
  on-secondary-container: '#fffbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#00174b'
  on-tertiary-container: '#497cff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#ffdad6'
  secondary-fixed-dim: '#ffb4ac'
  on-secondary-fixed: '#410002'
  on-secondary-fixed-variant: '#93000d'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#003ea8'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  title-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
  numeric-metric:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  numeric-table:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 3rem
---

## Brand & Style
The design system establishes a high-performance, institutional operating environment for higher education administration, faculty orchestration, and student lifecycles. It merges the structural rigor of classical academia with the kinetic precision of modern developer tools and financial infrastructure (Linear, Stripe). 

The emotional tone balances authority, absolute clarity, and frictionless workflow speed. Administrative density must never feel suffocating; instead, it projects calm competence, architectural order, and mission-critical reliability. 

Visually, the style combines modern corporate discipline with high-contrast structural containment. Deep obsidian architectural anchors (sidebar navigation and command modules) frame an ultra-crisp, bright-white workspace punctuated by decisive crimson inflection points.

## Colors
The color architecture enforces a strict information hierarchy, deliberately rationing high-chroma tones to preserve cognitive bandwidth during prolonged enterprise use.

### Canvas & Structural Backgrounds
- **Primary Canvas (`#FFFFFF`)**: Pure white base for active data grids, document canvases, and elevated cards.
- **Secondary Canvas (`#F8F8F8`)**: Foundation for page body behind cards, inactive tabs, and secondary side panels.
- **Table & Inset Headers (`#F5F5F5`)**: Grounded neutral tint for table header groups, list section dividers, and read-only metadata fields.
- **Sidebar Surface (`#111111`)**: Solid deep black column framing global context, workspace switching, and high-level routing.

### Text & Neutral Ramp
- **Primary Text (`#171717`)**: Near-black high-legibility tone for titles, values, table body, and active inputs.
- **Secondary Text (`#737373`)**: Balanced neutral for supporting descriptors, inactive labels, and breadcrumbs.
- **Muted Text (`#A3A3A3`)**: Restrained tone for placeholders, shortcut keys, and timestamps.
- **Standard Border (`#E5E5E5`)**: Crisp boundary line for inputs, card structures, and column splits.
- **Hairline Divider (`#EEEEEE`)**: Minimal boundary for interior row separators and list grouping.

### Primary Accent & Signals
- **Accent Crimson (`#E53935`)**: High-leverage semantic color reserved exclusively for primary action triggers, global notification badges, active route markers, and selected states. Never used decoratively across large surface areas.
- **Accent Hover (`#C62828`)**: Deepened red for interactive hover states.
- **Accent Light Wash (`#FDECEC`)**: Translucent red surface fill for active navigation pill fills, error highlights, and urgent tags.
- **Accent Border Tint (`#F5B7B1`)**: Border tone for active selection states and validation states.

### Status Palette
- **Success (`#16A34A`)**: Enrollment confirmed, grade published, tuition cleared.
- **Warning (`#D97706`)**: Prerequisites pending, capacity threshold at 90%, probation watch.
- **Error (`#DC2626`)**: Academic hold, system conflict, submission failed.
- **Information (`#2563EB`)**: Term advisories, schedule revisions, neutral institutional notices.

## Typography
Inter delivers systematic utilitarian clarity and tabular data performance. To ensure operational efficiency across grade sheets, registrar ledgers, and financial manifests, all numeric output must enable OpenType tabular numbers (`tnum`) and slashed zeros (`zero`).

### Type Scales and Hierarchies
- **Display & Large Headlines (`display-lg`, `headline-lg`)**: Primary view titles, executive enrollment metrics, and student profile banner names.
- **Section & Modal Titles (`headline-md`, `title-lg`, `title-md`)**: Drawer sheets, card headers, dialog headers, and data section groups.
- **Data & Reading Formats (`body-lg`, `body-md`, `body-sm`)**: Form text, transcript notes, long-form course syllabi, and contextual explanations.
- **Tags & Metadata (`label-md`, `label-sm`)**: Status chips, navigation badges, table headers (uppercase with tracking), and keyboard shortcut markers.
- **Metric & Quantitative Roles (`numeric-metric`, `numeric-table`)**: Dedicated roles enforcing `font-feature-settings: "tnum" 1, "cv05" 1` for consistent column alignment without horizontal jitter.

## Layout & Spacing
The layout follows a persistent multi-pane master-detail architecture engineered for data manipulation and administrative command.

### Structural Frame
- **Global Navigation Bar**: Fixed at `250px` width on the left flank, rendered in solid deep black (`#111111`), extending full viewport height (`100vh`).
- **Global Top Header**: Fixed at `68px` height with a bottom border (`#E5E5E5`), containing institution switchers, global search (`⌘K`), quick-action bars, and faculty profile avatars.
- **Canvas / Content Area**: Fluid container spanning the remaining viewport width, structured via a 12-column grid.

### Breakpoints & Fluid Adaptation
- **Desktop (≥ 1280px)**: 12-column grid with `1.5rem` (`24px`) gutters and `2rem` (`32px`) margins. Sidebar is locked open at `250px`.
- **Tablet (768px – 1279px)**: 8-column grid with `1rem` (`16px`) gutters and `1.5rem` (`24px`) margins. The sidebar collapses into a `64px` icon-only rail to prioritize administrative sheets.
- **Mobile (< 768px)**: 4-column grid with `1rem` margins. The sidebar moves to an off-canvas slide-out sheet triggered from the header. Complex tables convert to horizontal scroll lanes or vertically stacked summary cards.

## Elevation & Depth
Depth is produced primarily through crisp micro-borders and high-contrast surface transitions, rather than heavy skeuomorphic drop shadows. This maintains a clean, low-latency enterprise feel.

### Layer Stack
- **Floor 0 (Background Canvas)**: `#F8F8F8`. Base underlay behind content grids and panels.
- **Floor 1 (Surface Cards & Grids)**: `#FFFFFF` bounded by a `1px` solid border (`#E5E5E5`). Shadow is minimal: `0 1px 2px 0 rgba(0, 0, 0, 0.05)`.
- **Floor 2 (Floating Popovers, Menus & Filter Dropdowns)**: Elevated above data grids with `#FFFFFF` background, `1px` solid `#E5E5E5`, and a sharp ambient shadow: `0 4px 12px -2px rgba(17, 17, 17, 0.08), 0 2px 6px -1px rgba(17, 17, 17, 0.04)`.
- **Floor 3 (Slide-over Drawers & Modals)**: Critical administrative intervention surfaces backed by a translucent scrim (`rgba(17, 17, 17, 0.45)` with `backdrop-filter: blur(4px)`). Shadow: `0 20px 25px -5px rgba(0, 0, 0, 0.15), 0 8px 10px -6px rgba(0, 0, 0, 0.1)`.
- **Structural Separation**: Use `#EEEEEE` hairlines within components to partition secondary details rather than increasing card shadow depth.

## Shapes
A disciplined geometry balances modern software tactility with enterprise density:

- **Interactive Controls (Inputs, Buttons, Dropdowns)**: Standardized to `8px` corner radius. This prevents controls from feeling either harsh or toy-like.
- **Structural Containers (Metric Cards, Content Blocks, Modals)**: Standardized to `10px` or `12px` (`rounded-lg`) corner radius, creating clear outer containment around 8px children.
- **Badges, Tags, and Table Status Indicators**: Standardized to `4px` or `6px` (`rounded-sm`), maintaining a tight, industrial footprint within compact table cells.
- **Avatars & Active Nav Pills**: Fully circular (`rounded-full`) for people, or `6px` for navigation indicator blocks.

## Components

### Buttons
- **Primary CTA**: Background `#E53935`, text `#FFFFFF`, border none, radius `8px`, height `38px` (desktop) or `34px` (dense table context). Hover: `#C62828`. Active: `#B71C1C`. Focus: `0 0 0 2px #FFFFFF, 0 0 0 4px #E53935`.
- **Secondary (Dark/Neutral)**: Background `#111111`, text `#FFFFFF`, radius `8px`. Hover: `#262626`.
- **Tertiary / Outline**: Background `#FFFFFF`, text `#171717`, border `1px solid #E5E5E5`, radius `8px`. Hover: Background `#F5F5F5`, border `#D4D4D4`.
- **Ghost**: Background transparent, text `#737373`. Hover: Background `#F5F5F5`, text `#171717`.

### Input Fields & Controls
- **Text Inputs**: Height `38px`, background `#FFFFFF`, border `1px solid #E5E5E5`, radius `8px`, font size `14px`, text `#171717`, placeholder `#A3A3A3`. Focus: Border `#111111`, box-shadow `0 0 0 1px #111111`. Invalid: Border `#DC2626`, box-shadow `0 0 0 1px #DC2626`.
- **Checkboxes & Radios**: Size `16px`, border `1.5px solid #D4D4D4`, radius `4px` (checkbox) or `50%` (radio). Checked state: Background `#E53935`, border `#E53935`, white icon.

### Data Tables (SIS Core)
- **Header Row**: Height `40px`, background `#F5F5F5`, border-bottom `1px solid #E5E5E5`. Typography: `11px`, weight `600`, color `#737373`, uppercase, letter-spacing `0.04em`.
- **Data Rows**: Height `48px` (standard) or `36px` (compact registrar view), background `#FFFFFF`, border-bottom `1px solid #EEEEEE`. Hover: Background `#FAFAFA`. Selected row: Background `#FDECEC` with a `2px` left border in `#E53935`.

### Status Badges & Chips
- **Structure**: Height `22px`, padding `0 8px`, border-radius `4px`, font size `11px`, font-weight `600`.
- **Active / Enrolled**: Background `#DCFCE7`, text `#15803D`, border `1px solid #BBF7D0`.
- **Pending / In Review**: Background `#FEF3C7`, text `#B45309`, border `1px solid #FDE68A`.
- **Suspended / Hold**: Background `#FEE2E2`, text `#B91C1C`, border `1px solid #FECACA`.
- **Archived / Inactive**: Background `#F5F5F5`, text `#737373`, border `1px solid #E5E5E5`.

### Metric Cards
- Background `#FFFFFF`, border `1px solid #E5E5E5`, border-radius `10px`–`12px`, padding `16px`–`20px`. Top label in `12px` `#737373`, large KPI in `28px` `numeric-metric` `#171717`, bottom contextual Delta with micro-badge (green/red).

### Navigation Drawer (Sidebar)
- Background `#111111`, padding `16px 12px`.
- Nav links: Height `36px`, border-radius `6px`, text `#A3A3A3`, icon size `18px`. Hover: Background `rgba(255, 255, 255, 0.08)`, text `#FFFFFF`.
- Active Route: Background `rgba(229, 57, 53, 0.12)`, text `#FFFFFF`, left accent indicator `3px` solid `#E53935` (or crimson icon tint `#E53935`).